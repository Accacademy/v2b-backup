---
name: Bug report  | 问题反馈
about: Tell us what problems you have encountered
title: "[BUG]"
labels: ''
assignees: ''

---

🙇‍♂️🙇‍♂️🙇‍♂️注意：XrayR等非V2Board问题请前往项目方提问
🙇‍♂️🙇‍♂️🙇‍♂️Note: XrayR and other non-V2Board issues please go to the project side to ask questions


The V2Board version number you are using
当前使用的V2Board版本号
--------


Briefly describe the problem you are experiencing
简单描述你遇到的问题
--------



Screenshot of the reported error(Please do desensitization)
报告错误的截图（请做脱敏处理）
--------



Screenshot of the reported error(Please do desensitization)
报告错误的截图（请做脱敏处理）
--------



The latest log files in the storage/logs directory report from #1 (Please do desensitization)
storage/logs 目录下最新的日志文件从 #1 开始报告（请做脱敏处理）
--------
