window.settings.i18n = [
  'zh-CN',
  'en-US',
  'ja-JP',
  'vi-VN'
]
